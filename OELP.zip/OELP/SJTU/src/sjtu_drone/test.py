import rclpy
import numpy as np
from env import DroneRLEnvironmentNode
import time

def test_drone_environment():
    rclpy.init(args=None)
    env = DroneRLEnvironmentNode()
    
    print("Testing Drone RL Environment...")
    
    try:
        # Wait for the first odometry message
        while env.drone_x == 0.0 and env.drone_y == 0.0 and env.drone_z == 0.0:
            print("Waiting for sensor data...")
            rclpy.spin_once(env, timeout_sec=0.1)  # Allow callbacks to process messages
            time.sleep(0.1)  # Small delay to allow data reception

        # Now call state_space after ensuring data has arrived
        state = env.reset_env()
        print(f"Initial State: {state}")

        step_count = 0

        while True:
            action = np.random.uniform(-1.0, 1.0, size=(4,)).tolist()  # Generate random actions
            env.action_step(action)
            
            rclpy.spin_once(env, timeout_sec=0.1)  # Allow callbacks to update state
            
            next_state = env.state_space()
            print(f"  Action Taken: {action}")
            print(f"  Next State: {next_state}")

            state = next_state
            step_count += 1
    
    except KeyboardInterrupt:
        print("Keyboard Interrupt detected. Shutting down...")
    finally:
        env.destroy_node()
        rclpy.shutdown()
        print("ROS 2 shutdown completed.")

if __name__ == "__main__":
    test_drone_environment()
