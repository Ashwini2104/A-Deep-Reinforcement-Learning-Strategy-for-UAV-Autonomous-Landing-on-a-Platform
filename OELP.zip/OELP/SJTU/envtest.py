import os
import sys
import time
import random
import rclpy
import numpy as np
from rclpy.node import Node
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu
from std_msgs.msg import Empty  
from std_srvs.srv import Empty as srvempty 

from geometry_msgs.msg import Twist
from gazebo_msgs.srv import DeleteEntity, SpawnEntity, SetModelState
from gazebo_msgs.msg import ModelState
from geometry_msgs.msg import Pose, Twist
import xacro
import yaml





class DroneRLEnvironmentNode(Node):
    def __init__(self):
        super().__init__('drone_rl_environment')

        #.       
        # Subscribers
        self.imu_subscription = self.create_subscription(
            Imu,
            '/simple_drone/imu',
            self.imu_callback,
            10
        )
        self.odometry_subscription = self.create_subscription(
            Odometry,
            '/simple_drone/odom',
            self.odometry_callback,
            10
        )
         #added for height
        self.taken_off = False
        self.reached_altitude = False
        self.altitude_step = 0
    
        # Publishers
        self.cmd_vel_publisher = self.create_publisher(Twist, '/simple_drone/cmd_vel', 10)
        self.takeoff_publisher = self.create_publisher(Empty, '/simple_drone/takeoff', 10)
        self.land_publisher = self.create_publisher(Empty, '/simple_drone/land', 10)

        yaml_file_path = '/home/ashwini/Documents/OELP/SJTU/src/sjtu_drone/sjtu_drone_bringup/config/drone.yaml'
        xacro_file = '/home/ashwini/Documents/OELP/SJTU/src/sjtu_drone/sjtu_drone_description/urdf/sjtu_drone.urdf.xacro'
        
        robot_description_config = xacro.process_file(xacro_file, mappings={"params_path": yaml_file_path})
        self.robot_desc = robot_description_config.toxml()

        # Read the namespace
        with open(yaml_file_path, 'r') as f:
            yaml_dict = yaml.load(f, Loader=yaml.FullLoader)
            self.model_ns = yaml_dict["namespace"]

        # Define the new position for the drone (randomized within given bounds)
        self.new_position = [
            random.uniform(-8, 8),
            random.uniform(-8, 8),
            0.0
        ]
        # Create clients for resetting the world, deleting the drone, and spawning a new drone
        self.reset_world_client = self.create_client(srvempty, '/reset_world')
        while not self.reset_world_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for reset world service to be available...')
        
        self.delete_entity_client = self.create_client(DeleteEntity, '/delete_entity')
        while not self.delete_entity_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for delete entity service to be available...')
        
        self.spawn_client = self.create_client(SpawnEntity, '/spawn_entity')
        while not self.spawn_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for spawn service to be available...')
        
        # First, delete the existing drone entity if it exists
        # self.delete_entity()
        # State variables
        self.drone_x = 0.0
        self.drone_y = 0.0
        self.drone_z = 0.0
        self.drone_vx = 0.0
        self.drone_vy = 0.0
        self.drone_vz = 0.0
        
        # Target landing position
        self.target_x = -3  # Set your target x position
        self.target_y = -3  # Set your target y position
        self.target_z = 0.1  # Set your target z position
        
        # Previous shaping reward
        self.prev_shaping = None
        
        # Landing detection
        self.has_landed = False
        self.landing_height_threshold = 0.1  # Threshold to consider drone as landed
        
        # Alpha parameter for z-axis velocity control
        self.alpha = 0.5  # Adjust this value based on desired descent rate

    def imu_callback(self, msg):
        self.imu_data = msg

    def odometry_callback(self, msg):
        self.get_logger().info('Processing sensor data...')
        position = msg.pose.pose.position
        linear_velocity = msg.twist.twist.linear
        
        # Update drone state
        self.drone_x = position.x - self.target_x  # Relative to landing target
        self.drone_y = position.y - self.target_y
        self.drone_z = position.z - self.target_z
        self.drone_vx = linear_velocity.x
        self.drone_vy = linear_velocity.y
        self.drone_vz = linear_velocity.z
        
        # Check if drone has landed
        if abs(self.drone_z) < self.landing_height_threshold:
            self.has_landed = True
    
    def action_step(self, action_values):
        twist = Twist()
        # Scale actions to have more impact
        twist.linear.x = float(action_values[0]) * 1.5  # Increased scaling
        twist.linear.y = float(action_values[1]) * 1.5  # Increased scaling
        twist.linear.z = -self.alpha * self.drone_z  # az = α * pz
        twist.angular.z = 0.0  

        self.cmd_vel_publisher.publish(twist)
        
        # Add delay to let actions take effect
        time.sleep(0.1)
        
        new_state = self.state_space()
        reward = self.calculate_reward(action_values[0], action_values[1])
        
        # Check reset conditions
        if self.has_landed or self.out_of_bounds() or self.detect_crash():
            self.reset_env()
            return self.state_space(), reward, True
        
        return new_state, reward, False

    def calculate_reward(self, ax, ay):
     """
      Calculate the reward based on shaping function (Eq. 3) and reward function (Eq. 4).
     """
     position_term = -100 * (self.drone_x**2 + self.drone_y**2 + self.drone_z**2)
     velocity_term = -10 * (self.drone_vx**2 + self.drone_vy**2 + self.drone_vz**2)
     action_term = -np.sqrt(ax**2 + ay**2)
     # Landing bonus (C = 1 if drone lands on target, else 0)
     C = 1.0 if (self.has_landed and abs(self.drone_x ) < 0.1 and abs(self.drone_y ) < 0.1) else 0.0
     landing_bonus = 10 * C * (1 - abs(ax)) + 10 * C * (1 - abs(ay))
     current_shaping = position_term + velocity_term + action_term + landing_bonus
     if self.prev_shaping is None:
        reward = 0.0
     else:
        reward = current_shaping - self.prev_shaping
     # Update previous shaping value
     self.prev_shaping = current_shaping
     return reward
    
    def out_of_bounds(self):
     return not (-8 <= self.drone_x <= 8 and -8 <= self.drone_y <= 8 and 0 <= self.drone_z <= 8)

    def detect_crash(self):
     velocity_magnitude = np.linalg.norm([self.drone_vx, self.drone_vy, self.drone_vz])
     return velocity_magnitude > 5.0  # Adjust threshold as needed


    def reset_env(self):
        self.get_logger().info('Resetting environment...')
        
        # Land the drone first
        self.land_publisher.publish(Empty())
        time.sleep(2)  # Allow landing
        
        # Generate new random position
        self.new_position = [
            random.uniform(-8, 8),
            random.uniform(-8, 8),
            0.0
        ]
        
        # Delete and respawn the drone
        self.delete_entity()
        self.spawn_drone_at_position()  # Actually call this function
        
        # Take off the drone
        self.takeoff_publisher.publish(Empty())
        time.sleep(3.0)  # Allow time for takeoff
        
        self.ascend_to_altitude()
        time.sleep(0.5)
        
        # Reset state tracking
        self.has_landed = False
        self.prev_shaping = None
        
        # return self.state_space()
        # Verify altitude
        if self.drone_z < 2.9:
            self.get_logger().error('Drone failed to reach 3 meters!')
        else:
            self.get_logger().info("Drone successfully at 3 meters altitude.")

        return self.state_space()

    def delete_entity(self):
        self.get_logger().info(f"Deleting the existing drone entity...")
        
        # # Prepare delete request
        # delete_request = DeleteEntity.Request()
        # delete_request.name = "/simple_drone"  # Name of the entity to delete 

        # # Call delete entity service
        # self.delete_entity_client.call_async(delete_request)
        
        # Reset the world after deletion
        self.reset_world()

    def reset_world(self):
        self.get_logger().info("Resetting the world...")
        reset_request = srvempty.Request()
        self.reset_world_client.call_async(reset_request)

        # After resetting the world, spawn the drone
        # self.spawn_drone_at_position()

    def spawn_drone_at_position(self):
        self.get_logger().info(f"Spawning the drone at position {self.new_position}")

        # Create the pose for the new spawn position
                # Generate random spawn position


        pose = Pose()
        pose.position.x = self.new_position[0]
        pose.position.y = self.new_position[1]
        pose.position.z = self.new_position[2]
        pose.orientation.w = 1.0  # No rotation
        
        # Create the spawn request
        spawn_request = SpawnEntity.Request()
        spawn_request.name = "/simple_drone"
        spawn_request.xml = self.robot_desc
        spawn_request.initial_pose = pose
        spawn_request.robot_namespace = self.model_ns
        
        # Call the spawn service
        self.spawn_client.call_async(spawn_request)

    def ascend_to_altitude(self):
        target_time = 4  # Adjust based on the required ascent duration
        twist = Twist()
        twist.linear.z = 0.5

        start_time = time.time()
        while time.time() - start_time < target_time:
            print("Ascending...")
            self.cmd_vel_publisher.publish(twist)
            time.sleep(0.5)

        # Stop ascent
        self.cmd_vel_publisher.publish(Twist())
        self.reached_altitude = True
        self.get_logger().info("Estimated target altitude reached.")

    
    
    def generate_random_action(self):
        # Modified to match the paper's action space (ax, ay)
        return [
            random.uniform(-1.0, 1.0),  # ax
            random.uniform(-1.0, 1.0),  # ay
        ]

    def state_space(self):
        # State space matching Equation 1 from the paper
        state = np.array([
            self.drone_x,  # px
            self.drone_y,  # py
            self.drone_z,  # pz
            self.drone_vx, # vx
            self.drone_vy, # vy
            self.drone_vz, # vz
        ])
        return state

def main(args=None):
    rclpy.init(args=args)
    node = DroneRLEnvironmentNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()




