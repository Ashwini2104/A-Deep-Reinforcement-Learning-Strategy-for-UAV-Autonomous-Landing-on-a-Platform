import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
import random
import os
import csv
import rclpy
from collections import deque
from torch.utils.tensorboard import SummaryWriter
from envtest import DroneRLEnvironmentNode  # Import your custom ROS2-Gazebo environment



# Actor Network

class Actor(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Actor, self).__init__()
        self.fc1 = nn.Linear(state_dim, 256)
        self.fc2 = nn.Linear(256, 256)
        self.mean = nn.Linear(256, action_dim)
        self.log_std = nn.Linear(256, action_dim)

    def forward(self, state):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        mean = self.mean(x)
        log_std = self.log_std(x).clamp(-20, 2)
        return mean, log_std

    def sample(self, state):
        mean, log_std = self.forward(state)
        std = log_std.exp()
        action = mean + torch.randn_like(mean) * std
        log_prob = -0.5 * ((action - mean) / (std + 1e-6)).pow(2).sum(dim=1, keepdim=True)
        return action, log_prob


#  Q-Network (Critic)
class QNetwork(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(QNetwork, self).__init__()
        self.fc1 = nn.Linear(state_dim + action_dim, 256)
        self.fc2 = nn.Linear(256, 256)
        self.fc3 = nn.Linear(256, 1)

    def forward(self, state, action):
        x = torch.cat([state, action], dim=1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)



#Replay Buffer

class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = []
        self.position = 0

    def add(self, state, action, reward, next_state, done):
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.position] = (state, action, reward, next_state, done)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = zip(*batch)
        return np.array(state), np.array(action), np.array(reward), np.array(next_state), np.array(done)

    def __len__(self):
        return len(self.buffer)


#  SAC Agent

class SACAgent:
    def __init__(self, checkpoint_dir="checkpoints", log_file="training_log.csv"):
        rclpy.init()
        self.env = DroneRLEnvironmentNode()

        self.state_dim = 6  # State: [x, y, z, roll, pitch, yaw]
        self.action_dim = 2  # Action: [thrust, yaw_rate]

        # SAC Hyperparameters
        self.gamma = 0.99
        self.tau = 0.005
        self.alpha = 0.2
        self.target_entropy = -self.action_dim
        self.entropy_lr = 3e-4

        self.replay_buffer = ReplayBuffer(100000)
        self.batch_size = 64

        # Initialize Networks
        self.actor = Actor(self.state_dim, self.action_dim)
        self.q1 = QNetwork(self.state_dim, self.action_dim)
        self.q2 = QNetwork(self.state_dim, self.action_dim)

        self.target_q1 = QNetwork(self.state_dim, self.action_dim)
        self.target_q2 = QNetwork(self.state_dim, self.action_dim)

        self.target_q1.load_state_dict(self.q1.state_dict())
        self.target_q2.load_state_dict(self.q2.state_dict())

        # Optimizers
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=3e-4)
        self.q1_optimizer = optim.Adam(self.q1.parameters(), lr=3e-4)
        self.q2_optimizer = optim.Adam(self.q2.parameters(), lr=3e-4)

        # Entropy optimizer
        self.log_alpha = torch.tensor(np.log(self.alpha), requires_grad=True)
        self.alpha_optimizer = optim.Adam([self.log_alpha], lr=self.entropy_lr)

        # TensorBoard and Logging
        self.writer = SummaryWriter(log_dir="runs/SAC_training")
        self.checkpoint_dir = checkpoint_dir
        os.makedirs(checkpoint_dir, exist_ok=True)
        self.log_file = log_file
        self.init_logging()

    def select_action(self, state, eval=False):
        state = torch.FloatTensor(state).unsqueeze(0)
        mean, log_std = self.actor(state)
        std = log_std.exp()

        if eval:
            action = mean
        else:
            action = mean + torch.randn_like(mean) * std
        return action.detach().numpy()[0]

    def train(self):
        if len(self.replay_buffer) < self.batch_size:
            return None, None

        state, action, reward, next_state, done = self.replay_buffer.sample(self.batch_size)

        state = torch.FloatTensor(state)
        action = torch.FloatTensor(action)
        reward = torch.FloatTensor(reward).unsqueeze(1)
        next_state = torch.FloatTensor(next_state)
        done = torch.FloatTensor(done).unsqueeze(1)

        # Compute target Q values
        with torch.no_grad():
            next_action, next_log_pi = self.actor.sample(next_state)
            q1_target = self.target_q1(next_state, next_action)
            q2_target = self.target_q2(next_state, next_action)
            min_q_target = torch.min(q1_target, q2_target) - self.alpha * next_log_pi
            q_target = reward + self.gamma * (1 - done) * min_q_target

        # Update Q networks
        q1_pred = self.q1(state, action)
        q2_pred = self.q2(state, action)
        q1_loss = nn.MSELoss()(q1_pred, q_target)
        q2_loss = nn.MSELoss()(q2_pred, q_target)

        self.q1_optimizer.zero_grad()
        q1_loss.backward()
        self.q1_optimizer.step()

        self.q2_optimizer.zero_grad()
        q2_loss.backward()
        self.q2_optimizer.step()

        # Update Actor
        new_action, log_pi = self.actor.sample(state)
        q1_new_action = self.q1(state, new_action)
        q2_new_action = self.q2(state, new_action)
        min_q_new_action = torch.min(q1_new_action, q2_new_action)
        actor_loss = (self.alpha * log_pi - min_q_new_action).mean()

        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # Update Alpha (Entropy tuning)
        alpha_loss = -(self.log_alpha * (log_pi + self.target_entropy).detach()).mean()
        self.alpha_optimizer.zero_grad()
        alpha_loss.backward()
        self.alpha_optimizer.step()
        self.alpha = self.log_alpha.exp()

        # Soft update target networks
        self.update_target_networks()

        return q1_loss.item(), actor_loss.item()

    def update_target_networks(self):
        for target_param, param in zip(self.target_q1.parameters(), self.q1.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

        for target_param, param in zip(self.target_q2.parameters(), self.q2.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    def save_model(self, episode):
        torch.save(self.actor.state_dict(), f"{self.checkpoint_dir}/actor_{episode}.pth")
        torch.save(self.q1.state_dict(), f"{self.checkpoint_dir}/q1_{episode}.pth")
        torch.save(self.q2.state_dict(), f"{self.checkpoint_dir}/q2_{episode}.pth")

    def init_logging(self):
        with open(self.log_file, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Episode", "Reward", "Q1 Loss", "Actor Loss", "Alpha"])

    def log_training(self, episode, reward, q1_loss, actor_loss):
        with open(self.log_file, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([episode, reward, q1_loss, actor_loss, self.alpha.item()])

    def train_agent(self, num_timesteps, save_interval=5000):
        timestep = 0
        episode_reward = 0
        episode_count = 0
        state = self.env.reset_env()

        while timestep < num_timesteps:
            rclpy.spin_once(self.env)
            action = self.select_action(state)
            next_state, reward, done = self.env.action_step(action)

            # Convert reward to float for safety
            reward = float(reward)
            episode_reward += reward
            self.replay_buffer.add(state, action, reward, next_state, done)

            # Train only if enough samples exist in replay buffer
            q1_loss, actor_loss = self.train()

            if done:
                # Log reward per episode
                self.writer.add_scalar("Reward/Episode", episode_reward, episode_count)
                print(f"Episode {episode_count}: Reward = {episode_reward}")

                # Reset for new episode
                episode_reward = 0
                state = self.env.reset_env()
                episode_count += 1
            else:
                state = next_state  # Continue with next state

            # Log losses and alpha if training was performed
            if q1_loss is not None and actor_loss is not None:
                self.writer.add_scalar("Loss/Q1", q1_loss, timestep)
                self.writer.add_scalar("Loss/Actor", actor_loss, timestep)
                if self.alpha is not None:
                    self.writer.add_scalar("Entropy/Alpha", self.alpha.item(), timestep)

            # Save model periodically (avoid saving at timestep 0)
            if timestep > 0 and timestep % save_interval == 0:
                self.save_model(timestep)
                print(f"Model checkpoint saved at timestep {timestep}")

            timestep += 1  # Always increment timestep

    Self.writer.close()  # Ensure TensorBoard logging is finalized
    print("Training complete!")






# Run Training

if __name__ == "__main__":
    agent = SACAgent()
    agent.train_agent(num_timesteps=2000000)
