import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
import rclpy
import os
import csv
from collections import deque
from envtest import DroneRLEnvironmentNode

# Define Actor and Critic networks
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Actor, self).__init__()
        self.fc1 = nn.Linear(state_dim, 256)
        self.fc2 = nn.Linear(256, 256)
        self.fc3 = nn.Linear(256, action_dim)
        self.activation = nn.Tanh()

    def forward(self, state):
        x = torch.relu(self.fc1(state))
        x = torch.relu(self.fc2(x))
        x = self.activation(self.fc3(x))
        return x

class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Critic, self).__init__()
        self.fc1 = nn.Linear(state_dim + action_dim, 256)
        self.fc2 = nn.Linear(256, 256)
        self.fc3 = nn.Linear(256, 1)

    def forward(self, state, action):
        x = torch.cat([state, action], dim=1)
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

# DDPG Agent
class DDPGAgent:
    def __init__(self, checkpoint_dir="checkpoints", log_file="training_log.csv"):
        rclpy.init()
        self.env = DroneRLEnvironmentNode()

        self.state_dim = 6
        self.action_dim = 2
        self.initialize_networks()

        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=1e-4)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=1e-3)

        self.replay_buffer = deque(maxlen=100000)
        self.batch_size = 64
        self.gamma = 0.99
        self.tau = 0.005
        self.noise_std = 0.2

        self.checkpoint_dir = checkpoint_dir
        os.makedirs(checkpoint_dir, exist_ok=True)
        self.log_file = log_file
        self.init_logging()

    def initialize_networks(self):
        self.actor = Actor(self.state_dim, self.action_dim)
        self.critic = Critic(self.state_dim, self.action_dim)
        self.target_actor = Actor(self.state_dim, self.action_dim)
        self.target_critic = Critic(self.state_dim, self.action_dim)
        self.target_actor.load_state_dict(self.actor.state_dict())
        self.target_critic.load_state_dict(self.critic.state_dict())

    def select_action(self, state, add_noise=True):
        state = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        action = self.actor(state).detach().numpy()[0]
        if add_noise:
            action += np.random.normal(0, self.noise_std, size=self.action_dim)
            action = np.clip(action, -1.0, 1.0)
        return action

    def train(self):
        if len(self.replay_buffer) < self.batch_size:
            return None, None
        batch = random.sample(self.replay_buffer, self.batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        
        states = torch.tensor(np.array(states), dtype=torch.float32)
        actions = torch.tensor(np.array(actions), dtype=torch.float32)
        rewards = torch.tensor(np.array(rewards), dtype=torch.float32).unsqueeze(1)
        next_states = torch.tensor(np.array(next_states), dtype=torch.float32)
        dones = torch.tensor(np.array(dones), dtype=torch.float32).unsqueeze(1)

        next_actions = self.target_actor(next_states)
        next_Q_values = self.target_critic(next_states, next_actions)
        target_Q = rewards + self.gamma * next_Q_values * (1 - dones)

        current_Q = self.critic(states, actions)
        critic_loss = nn.MSELoss()(current_Q, target_Q.detach())
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        actor_loss = -self.critic(states, self.actor(states)).mean()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        self.update_target_networks()
        return critic_loss.item(), actor_loss.item()

    def update_target_networks(self):
        for target_param, param in zip(self.target_actor.parameters(), self.actor.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        for target_param, param in zip(self.target_critic.parameters(), self.critic.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    def save_model(self, episode):
        torch.save(self.actor.state_dict(), f"{self.checkpoint_dir}/actor_{episode}.pth")
        torch.save(self.critic.state_dict(), f"{self.checkpoint_dir}/critic_{episode}.pth")

    def init_logging(self):
        with open(self.log_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Episode", "Reward", "Critic Loss", "Actor Loss", "Success Rate", "Collision Rate"])

    def log_training(self, episode, reward, critic_loss, actor_loss, success_rate, collision_rate):
        with open(self.log_file, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([episode, reward, critic_loss, actor_loss, success_rate, collision_rate])

    def train_agent(self, num_episodes, save_interval=50):
        success_count = 0
        collision_count = 0

        for episode in range(1000):
            state = self.env.reset_env()
            episode_reward = 0
            for step in range(500):
                action = self.select_action(state)
                next_state, reward, done = self.env.action_step(action)
                self.replay_buffer.append((state, action, reward, next_state, done))
                critic_loss, actor_loss = self.train()
                state = next_state
                episode_reward += reward
                if done:
                    if self.env.successful_landing():
                        success_count += 1
                    elif self.env.collision_occurred():
                        collision_count += 1
                    break
            success_rate = success_count / (episode + 1)
            collision_rate = collision_count / (episode + 1)
            self.log_training(episode, episode_reward, critic_loss, actor_loss, success_rate, collision_rate)
            if (episode + 1) % save_interval == 0:
                self.save_model(episode + 1)
            print(f"Episode {episode + 1}/{num_episodes}, Reward: {episode_reward}, Success Rate: {success_rate:.2f}, Collision Rate: {collision_rate:.2f}")

if __name__ == "__main__":
    agent = DDPGAgent()
    agent.train_agent(num_episodes=1000)
