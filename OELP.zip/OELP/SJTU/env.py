import os
import sys
import time
import random
import rclpy
import numpy as np
import rclpy.logging
from rclpy.node import Node
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu
from std_msgs.msg import Empty
from geometry_msgs.msg import Twist
from std_srvs.srv import Empty as srvempty 


class DroneRLEnvironmentNode(Node):
    def __init__(self):
        super().__init__('drone_rl_environment')

        # Subscribers
        self.imu_subscription = self.create_subscription(
            Imu,
            '/simple_drone/imu/out',
            self.imu_callback,
            10
        )
        self.odometry_subscription = self.create_subscription(
            Odometry,
            '/simple_drone/odom',
            self.odometry_callback,
            10
        )

        # Publishers
        self.cmd_vel_publisher = self.create_publisher(Twist, '/simple_drone/cmd_vel', 10)
        self.takeoff_publisher = self.create_publisher(Empty, '/simple_drone/takeoff', 10)
        self.land_publisher = self.create_publisher(Empty, '/simple_drone/land', 10)

        # Create clients for resetting the world, deleting the drone, and spawning a new drone
        self.reset_world_client = self.create_client(srvempty, '/reset_world')
        while not self.reset_world_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for reset world service to be available...')
        


        # State variables
        self.drone_x = 0.0
        self.drone_y = 0.0
        self.drone_z = 0.0
        self.drone_vx = 0.0
        self.drone_vy = 0.0
        self.drone_vz = 0.0
        
        # Target landing position
        self.target_x = -3.0  # Set your target x position
        self.target_y = -3.0  # Set your target y position
        self.target_z = 0.1  # Set your target z position
        
        # Previous shaping reward
        self.prev_shaping = None
        
        # Landing detection
        self.has_landed = False
        self.landing_height_threshold = 0.1  # Threshold to consider drone as landed
        
        # Alpha parameter for z-axis velocity control
        self.alpha = 0.5  # Adjust this value based on desired descent rate

    def reset_world(self):
        self.get_logger().info("Resetting the world...")
        reset_request = srvempty.Request()
        self.reset_world_client.call_async(reset_request)


    def imu_callback(self, msg):
        self.imu_data = msg
        self.drone_vx = msg.linear_acceleration.x
        self.drone_vy = msg.linear_acceleration.y
        self.drone_vz = msg.linear_acceleration.z
        self.get_logger().info(f"linear.x :{self.drone_vx}, linear.y :{self.drone_vy}, linear.z :{self.drone_vz}")


    def odometry_callback(self, msg):
        self.get_logger().info('Processing sensor data...')
        position = msg.pose.pose.position
        linear_velocity = msg.twist.twist.linear
        
        # Update drone state
        self.drone_x = position.x - self.target_x  # Relative to landing target
        self.drone_y = position.y - self.target_y
        self.drone_z = position.z - self.target_z
        # self.drone_vx = linear_velocity.x
        # self.drone_vy = linear_velocity.y
        # self.drone_vz = linear_velocity.z
        
        # Check if drone has landed
        if abs(self.drone_z) < self.landing_height_threshold:
            self.has_landed = True

    def action_step(self, action_values):
     twist = Twist()
     twist.linear.x = float(action_values[0])  # ax
     twist.linear.y = float(action_values[1])
     twist.linear.z = -self.alpha * self.drone_z  # az = α * pz
     twist.angular.z = 0.0  

     self.cmd_vel_publisher.publish(twist)
    
     new_state = self.state_space()
     reward = self.calculate_reward(action_values[0], action_values[1])
    
     # Check reset conditions
     if self.has_landed :
        self.reset_env()
        return self.state_space(), reward, True  # Return new state, reward, and done=True
    
     return new_state, reward, False

    def calculate_reward(self, ax, ay):
     """
      Calculate the reward based on shaping function (Eq. 3) and reward function (Eq. 4).
     """
    #  print("calulating reward")
     position_term = -100 * (self.drone_x**2 + self.drone_y**2 + self.drone_z**2)
     velocity_term = -10 * (self.drone_vx**2 + self.drone_vy**2 + self.drone_vz**2)
     action_term = -np.sqrt(ax**2 + ay**2)
     # Landing bonus (C = 1 if drone lands on target, else 0)
     C = 1.0 if (self.has_landed and abs(self.drone_x + 3) < 0.1 and abs(self.drone_y + 3) < 0.1) else 0.0
     landing_bonus = 10 * C * (1 - abs(ax)) + 10 * C * (1 - abs(ay))
     current_shaping = position_term + velocity_term + action_term + landing_bonus
     if self.prev_shaping is None:
        reward = 0.0
     else:
        reward = current_shaping - self.prev_shaping
     # Update previous shaping value
     self.prev_shaping = current_shaping
    #  print(reward)
     return reward

    
    def out_of_bounds(self):
     return not (-8 <= self.drone_x <= 8 and -8 <= self.drone_y <= 8 and 0 <= self.drone_z <= 8)


    def detect_crash(self):
     velocity_magnitude = np.linalg.norm([self.drone_vx, self.drone_vy, self.drone_vz])
     return velocity_magnitude > 5.0  # Adjust threshold as needed


    def reset_env(self):
        self.get_logger().info('Resetting environment...')
        
        # Stop the drone
        stop_cmd = Twist()
        self.cmd_vel_publisher.publish(stop_cmd)

        # Land and takeoff sequence
        land_msg = Empty()
        self.land_publisher.publish(land_msg)
        time.sleep(2)

        self.reset_world()

        takeoff_msg = Empty()
        self.takeoff_publisher.publish(takeoff_msg)
        time.sleep(2)

        self.get_logger().info('Environment reset complete.')
        # Reset state variables
        self.has_landed = False
        self.prev_shaping = None
        return self.state_space()


    def state_space(self):
        # State space matching Equation 1 from the paper
        state = np.array([
            self.drone_x,  # px
            self.drone_y,  # py
            self.drone_z,  # pz
            self.drone_vx, # vx
            self.drone_vy, # vy
            self.drone_vz, # vz
        ])
        return state

def main(args=None):
    rclpy.init(args=args)
    node = DroneRLEnvironmentNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()