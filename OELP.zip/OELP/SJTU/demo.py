#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Vector3
from std_msgs.msg import Empty
import time

class TeleopNode(Node):
    def __init__(self) -> None:
        super().__init__('teleop_node')

        # Publishers
        self.cmd_vel_publisher = self.create_publisher(Twist, '/simple_drone/cmd_vel', 10)
        self.takeoff_publisher = self.create_publisher(Empty, '/simple_drone/takeoff', 10)
        self.land_publisher = self.create_publisher(Empty, '/simple_drone/land', 10)

        # Velocity parameters
        self.linear_velocity = 0.5  # m/s
        self.angular_velocity = 0.5  # rad/s
        self.side_length = 2.0  # meters for the square path

    def move_forward(self, distance: float) -> None:
        """
        Move the drone forward for a specific distance.
        """
        duration = distance / self.linear_velocity
        linear_vec = Vector3(x=self.linear_velocity)
        self.publish_cmd_vel(linear_vec)
        time.sleep(duration)
        self.publish_cmd_vel()  # Stop the movement

    def rotate(self, angle: float) -> None:
        """
        Rotate the drone by a specific angle (in radians).
        """
        duration = angle / self.angular_velocity
        angular_vec = Vector3(z=self.angular_velocity)
        self.publish_cmd_vel(angular_vec=angular_vec)
        time.sleep(duration)
        self.publish_cmd_vel()  # Stop the rotation

    def fly_square(self) -> None:
        """
        Fly the drone in a square path.
        """
        # Take off
        self.takeoff_publisher.publish(Empty())
        time.sleep(5)  # Wait for drone to stabilize in air
        
        for _ in range(4):
            self.move_forward(self.side_length)  # Move forward by 2 meters
            self.rotate(1.57)  # Rotate 90 degrees (1.57 radians)

        # Land the drone
        self.land_publisher.publish(Empty())

    def publish_cmd_vel(self, linear_vec: Vector3 = Vector3(), angular_vec: Vector3 = Vector3()) -> None:
        """
        Publish a Twist message to cmd_vel topic
        """
        twist = Twist(linear=linear_vec, angular=angular_vec)
        self.cmd_vel_publisher.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    teleop_node = TeleopNode()
    teleop_node.fly_square()  # Execute the square flight sequence
    rclpy.spin(teleop_node)
    teleop_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()