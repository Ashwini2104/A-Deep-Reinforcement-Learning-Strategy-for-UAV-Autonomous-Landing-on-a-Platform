import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
import rclpy
from collections import deque
from env import DroneRLEnvironmentNode

# Define Actor and Critic networks
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Actor, self).__init__()
        self.fc1 = nn.Linear(state_dim, 256)
        self.fc2 = nn.Linear(256, 256)
        self.fc3 = nn.Linear(256, action_dim)
        self.activation = nn.Tanh()  # Actions are bounded

    def forward(self, state):
        x = torch.relu(self.fc1(state))
        x = torch.relu(self.fc2(x))
        x = self.activation(self.fc3(x))  # Ensure actions are in range
        return x

class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Critic, self).__init__()
        self.fc1 = nn.Linear(state_dim + action_dim, 256)
        self.fc2 = nn.Linear(256, 256)
        self.fc3 = nn.Linear(256, 1)

    def forward(self, state, action):
        x = torch.cat([state, action], dim=1)
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

# DDPG Agent
class DDPGAgent:
    def __init__(self):
        rclpy.init()
        self.env = DroneRLEnvironmentNode()  # Import environment

        # Define state and action dimensions
        self.state_dim = 6   # [px, py, pz, vx, vy, vz]
        self.action_dim = 2  # [ax, ay]

        # Initialize networks
        self.initialize_networks()

        # Optimizers
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=1e-4)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=1e-3)

        # Replay buffer
        self.replay_buffer = deque(maxlen=100000)
        self.batch_size = 64

        # Discount factor and soft update coefficient
        self.gamma = 0.99
        self.tau = 0.005

        # Exploration noise
        self.noise_std = 0.2

    def initialize_networks(self):
        """Set up actor and critic neural networks."""
        self.actor = Actor(self.state_dim, self.action_dim)
        self.critic = Critic(self.state_dim, self.action_dim)

        self.target_actor = Actor(self.state_dim, self.action_dim)
        self.target_critic = Critic(self.state_dim, self.action_dim)

        # Copy weights
        self.target_actor.load_state_dict(self.actor.state_dict())
        self.target_critic.load_state_dict(self.critic.state_dict())

    def select_action(self, state, add_noise=True):
        """Choose action with exploration noise."""
        state = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        action = self.actor(state).detach().numpy()[0]
        
        if add_noise:
            action += np.random.normal(0, self.noise_std, size=self.action_dim)
            action = np.clip(action, -1.0, 1.0)  # Keep action within valid range
        
        return action

    def update_target_networks(self):
        """Soft update target networks."""
        for target_param, param in zip(self.target_actor.parameters(), self.actor.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

        for target_param, param in zip(self.target_critic.parameters(), self.critic.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    def train(self, batch_size):
        """Train actor and critic using replay buffer."""
        if len(self.replay_buffer) < batch_size:
            return  # Not enough samples

        batch = random.sample(self.replay_buffer, batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)

        states = torch.tensor(np.array(states), dtype=torch.float32)
        actions = torch.tensor(np.array(actions), dtype=torch.float32)
        rewards = torch.tensor(np.array(rewards), dtype=torch.float32).unsqueeze(1)
        next_states = torch.tensor(np.array(next_states), dtype=torch.float32)
        dones = torch.tensor(np.array(dones), dtype=torch.float32).unsqueeze(1)

        # Compute target Q value
        next_actions = self.target_actor(next_states)
        next_Q_values = self.target_critic(next_states, next_actions)
        target_Q = rewards + self.gamma * next_Q_values * (1 - dones)

        # Update Critic
        current_Q = self.critic(states, actions)
        critic_loss = nn.MSELoss()(current_Q, target_Q.detach())
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # Update Actor
        actor_loss = -self.critic(states, self.actor(states)).mean()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # Update target networks
        self.update_target_networks()

    def reset_env(self):
        """Reset the drone environment."""
        return self.env.reset_env()

    def get_drone_state(self):
        """Get the drone’s state (position, velocity)."""
        return self.env.get_drone_state()

    def step(self, action):
     """Take action, return next state and reward."""
     action = np.array(action, dtype=np.float32)  # action is float
     new_state, reward, done = self.env.action_step(action)
     return new_state, reward, done


    def check_done(self):
        """Check if the episode should terminate."""
        return self.env.has_landed

    def train_agent(self, num_episodes):
        """Full training loop."""
        for episode in range(num_episodes):
            state = self.reset_env()
            episode_reward = 0

            for step in range(500):  # Max steps per episode
                action = self.select_action(state)
                next_state, reward, done = self.step(action)

                # Store experience in replay buffer
                self.replay_buffer.append((state, action, reward, next_state, done))

                # Train the agent
                self.train(self.batch_size)

                state = next_state
                episode_reward += reward

                if done:
                    break  # End episode if landing is successful

            print(f"Episode {episode + 1}/{num_episodes}, Reward: {episode_reward}")

        print("Training complete.")

if __name__ == "__main__":
    agent = DDPGAgent()
    agent.train_agent(num_episodes=1000)
