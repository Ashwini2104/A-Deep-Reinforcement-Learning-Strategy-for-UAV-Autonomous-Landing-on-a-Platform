import os
import sys
import time
import random
import rclpy
import numpy as np
from rclpy.node import Node
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu
from std_msgs.msg import Empty
from geometry_msgs.msg import Twist

class DroneRLEnvironmentNode(Node):
    def __init__(self):
        super().__init__('drone_rl_environment')

        # Subscribers
        self.imu_subscription = self.create_subscription(
            Imu,
            '/simple_drone/imu',
            self.imu_callback,
            10
        )
        self.odometry_subscription = self.create_subscription(
            Odometry,
            '/simple_drone/odom',
            self.odometry_callback,
            10
        )

        # Publishers
        self.cmd_vel_publisher = self.create_publisher(Twist, '/simple_drone/cmd_vel', 10)
        self.takeoff_publisher = self.create_publisher(Empty, '/simple_drone/takeoff', 10)
        self.land_publisher = self.create_publisher(Empty, '/simple_drone/land', 10)

        # State variables
        self.drone_x = 0.0
        self.drone_y = 0.0
        self.drone_z = 0.0
        self.drone_vx = 0.0
        self.drone_vy = 0.0
        self.drone_vz = 0.0
        
        # Target landing position
        self.target_x = -3.0  # Set your target x position
        self.target_y = -3.0  # Set your target y position
        self.target_z = 0.1  # Set your target z position
        
        # Previous shaping reward
        self.prev_shaping = None
        
        # Landing detection
        self.has_landed = False
        self.landing_height_threshold = 0.1  # Threshold to consider drone as landed
        
        # Alpha parameter for z-axis velocity control
        self.alpha = 0.5  # Adjust this value based on desired descent rate

    def imu_callback(self, msg):
        self.imu_data = msg

    def odometry_callback(self, msg):
        self.get_logger().info('Processing sensor data...')
        position = msg.pose.pose.position
        linear_velocity = msg.twist.twist.linear
        
        # Update drone state
        self.drone_x = position.x - self.target_x  # Relative to landing target
        self.drone_y = position.y - self.target_y
        self.drone_z = position.z - self.target_z
        self.drone_vx = linear_velocity.x
        self.drone_vy = linear_velocity.y
        self.drone_vz = linear_velocity.z
        
        # Check if drone has landed
        if abs(self.drone_z) < self.landing_height_threshold:
            self.has_landed = True

    def action_step(self, action_values):
        # Modify action space to match the paper (ax, ay)
        twist = Twist()
        twist.linear.x = action_values[0]  # ax
        twist.linear.y = action_values[1]  # ay
        twist.linear.z = -self.alpha * self.drone_z  # az = α * pz
        twist.angular.z = 0.0  # We don't control yaw as per the paper

        self.cmd_vel_publisher.publish(twist)
        
        # Return new state and reward
        new_state = self.state_space()
        reward = self.calculate_reward(action_values[0], action_values[1])
        done = self.has_landed
        
        return new_state, reward, done

    def calculate_reward(self, ax, ay):
        # Calculate current shaping reward based on Equation 3
        position_term = -100 * np.sqrt(self.drone_x**2 + self.drone_y**2 + self.drone_z**2)
        velocity_term = -10 * np.sqrt(self.drone_vx**2 + self.drone_vy**2 + self.drone_vz**2)
        action_term = -np.sqrt(ax**2 + ay**2)
        
        # Landing bonus term (C parameter)
        C = 1.0 if self.has_landed else 0.0
        landing_bonus = 10 * C * (1 - abs(ax)) + 10 * C * (1 - abs(ay))
        
        current_shaping = position_term + velocity_term + action_term + landing_bonus
        
        # Calculate reward based on Equation 4
        if self.prev_shaping is None:
            reward = 0.0
        else:
            reward = current_shaping - self.prev_shaping
        
        self.prev_shaping = current_shaping
        return reward

    def reset_env(self):
        self.get_logger().info('Resetting environment...')
        
        # Reset state variables
        self.has_landed = False
        self.prev_shaping = None
        
        # Stop the drone
        stop_cmd = Twist()
        self.cmd_vel_publisher.publish(stop_cmd)

        # Land and takeoff sequence
        land_msg = Empty()
        self.land_publisher.publish(land_msg)
        time.sleep(2)

        takeoff_msg = Empty()
        self.takeoff_publisher.publish(takeoff_msg)
        time.sleep(2)

        self.get_logger().info('Environment reset complete.')
        return self.state_space()
    

    def generate_random_action(self):
        # Modified to match the paper's action space (ax, ay)
        return [
            random.uniform(-1.0, 1.0),  # ax
            random.uniform(-1.0, 1.0),  # ay
        ]

    def state_space(self):
        # State space matching Equation 1 from the paper
        state = np.array([
            self.drone_x,  # px
            self.drone_y,  # py
            self.drone_z,  # pz
            self.drone_vx, # vx
            self.drone_vy, # vy
            self.drone_vz, # vz
        ])
        return state

def main(args=None):
    rclpy.init(args=args)
    node = DroneRLEnvironmentNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()