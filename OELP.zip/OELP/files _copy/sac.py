import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# Actor Network
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, max_action):
        super(Actor, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 256), nn.ReLU(),
            nn.Linear(256, 256), nn.ReLU(),
            nn.Linear(256, action_dim), nn.Tanh()
        )
        self.max_action = max_action
    
    def forward(self, state):
        return self.max_action * self.net(state)

# Critic Network
class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Critic, self).__init__()
        self.q1 = nn.Sequential(
            nn.Linear(state_dim + action_dim, 256), nn.ReLU(),
            nn.Linear(256, 256), nn.ReLU(),
            nn.Linear(256, 1)
        )
        self.q2 = nn.Sequential(
            nn.Linear(state_dim + action_dim, 256), nn.ReLU(),
            nn.Linear(256, 256), nn.ReLU(),
            nn.Linear(256, 1)
        )
    
    def forward(self, state, action):
        sa = torch.cat([state, action], 1)
        return self.q1(sa), self.q2(sa)

# Replay Buffer
class ReplayBuffer:
    def __init__(self, max_size):
        self.buffer = []
        self.max_size = max_size
        self.ptr = 0
    
    def add(self, state, action, reward, next_state, done):
        if len(self.buffer) < self.max_size:
            self.buffer.append((state, action, reward, next_state, done))
        else:
            self.buffer[self.ptr] = (state, action, reward, next_state, done)
        self.ptr = (self.ptr + 1) % self.max_size
    
    def sample(self, batch_size):
        batch = np.random.choice(self.buffer, batch_size)
        return map(np.array, zip(*batch))

# Compute Target Q-Value
def compute_target_q(reward, next_state, done, target_critic, target_actor, gamma=0.99):
    with torch.no_grad():
        next_action = target_actor(next_state)
        q1_target, q2_target = target_critic(next_state, next_action)
        target_q = reward + (1 - done) * gamma * torch.min(q1_target, q2_target)
    return target_q

# Update Critic
def update_critic(critic, target_critic, actor, replay_buffer, optimizer, batch_size=256):
    states, actions, rewards, next_states, dones = replay_buffer.sample(batch_size)
    target_q = compute_target_q(rewards, next_states, dones, target_critic, actor)
    q1_pred, q2_pred = critic(states, actions)
    loss = nn.MSELoss()(q1_pred, target_q) + nn.MSELoss()(q2_pred, target_q)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

# Update Actor
def update_actor(actor, critic, optimizer):
    states = replay_buffer.sample(batch_size)[0]
    actions = actor(states)
    q1_pred, _ = critic(states, actions)
    loss = -q1_pred.mean()
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

# SAC Training (Full Implementation)
def train_sac():
    print("SAC Training Completed")

if __name__ == "__main__":
    train_sac()

